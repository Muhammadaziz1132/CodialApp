package ramizbek.aliyev.codialapp.utils

import ramizbek.aliyev.codialapp.models.*

object MyObject {
    var tvAllCourseNames = ""
    var booleanAddCourses = true
    var courses = Courses()
    var mentors = Mentors()
    var groups = Groups()
    var students = Students()
    var navigationID = 0
    var editStudents = false
    var raqam = 0

}